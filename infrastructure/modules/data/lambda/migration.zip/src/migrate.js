const { Client } = require('pg')
const fs = require('fs')
const path = require('path')

// Only require AWS SDK when running in Lambda
const isLambda = !!process.env.AWS_LAMBDA_FUNCTION_NAME
const SSM = isLambda ? require('@aws-sdk/client-ssm').SSM : null

exports.migrate = async function() {
  const client = new Client({
    // Split host and port from DB_HOST (which comes in format: hostname:port)
    host: process.env.DB_HOST.split(':')[0],
    port: parseInt(process.env.DB_PORT || '5432'),
    database: process.env.DB_NAME || 'messages',
    user: process.env.DB_USER || 'postgres',
    password: process.env.DB_PASSWORD
  })

  try {
    await client.connect()
    
    // Get all migration files
    const migrationsDir = path.join(__dirname, '../migrations')
    const migrations = fs.readdirSync(migrationsDir)
      .filter(f => f.endsWith('.sql'))
      .sort()
    
    // Run each migration
    for (const migration of migrations) {
      console.log(`Running migration: ${migration}`)
      const sql = fs.readFileSync(path.join(migrationsDir, migration), 'utf8')
      await client.query(sql)
    }

    // Update SSM parameter only when running in Lambda
    if (isLambda) {
      const ssm = new SSM({})
      const paramName = `/${process.env.ENVIRONMENT}/migration-status`
      
      await ssm.putParameter({
        Name: paramName,
        Value: 'complete',
        Type: 'String',
        Overwrite: true
      })
    }

    console.log('Migration completed successfully')
  } catch (error) {
    console.error('Migration failed:', error)
    throw error
  } finally {
    await client.end()
  }
}

// Allow both Lambda and direct execution
if (require.main === module) {
  exports.migrate().catch(err => {
    console.error(err)
    process.exit(1)
  })
} else {
  // exports.migrate is already defined above
} 